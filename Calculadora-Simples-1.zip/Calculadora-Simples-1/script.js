function calcularComIf() {
  const valor1 = parseFloat(document.getElementById('valor1').value);
  const valor2 = parseFloat(document.getElementById('valor2').value);
  const operacao = document.getElementById('operacao').value;
  let resultado;

  // Verifica se os valores são números válidos
  if (isNaN(valor1) || isNaN(valor2)) {
      resultado = 'Erro: Valores inválidos';
  } else {
      if (operacao === '+') {
          resultado = valor1 + valor2;
      } else if (operacao === '-') {
          resultado = valor1 - valor2;
      } else if (operacao === '*') {
          resultado = valor1 * valor2;
      } else if (operacao === '/') {
          if (valor2 !== 0) {
              resultado = valor1 / valor2;
          } else {
              resultado = 'Erro: Divisão por zero';
          }
      } else {
          resultado = 'Erro: Operação inválida';
      }
  }


  document.getElementById('resultado').value = resultado;
}

function calcularComSwitch() {
  const valor1 = parseFloat(document.getElementById('valor1').value);
  const valor2 = parseFloat(document.getElementById('valor2').value);
  const operacao = document.getElementById('operacao').value;
  let resultado;

  // Verifica se os valores são números válidos
  if (isNaN(valor1) || isNaN(valor2)) {
      resultado = 'Erro: Valores inválidos';
  } else {
      switch (operacao) {
          case '+':
              resultado = valor1 + valor2;
              break;
          case '-':
              resultado = valor1 - valor2;
              break;
          case '*':
              resultado = valor1 * valor2;
              break;
          case '/':
              if (valor2 !== 0) {
                  resultado = valor1 / valor2;
              } else {
                  resultado = 'Erro: Divisão por zero';
              }
              break;
          default:
              resultado = 'Erro: Operação inválida';
              break;
      }
  }

  
  document.getElementById('resultado').value = resultado;
}